<?php
Class RateBadminton{
Public $RateBadmintonID;
Public $TypeRatePerson;
Public $TerminalGym;
Public $PriceMemberPerYear;
Public $PriceMember;
Public $PriceNotMember;

Public function RateBadminton($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember)
{            
           $this-> RateBadmintonID = $RateBadmintonID;
           $this->TypeRatePerson = $TypeRatePerson;
           $this->TerminalGym = $TerminalGym;
           $this-> PriceMemberPerYear= $PriceMemberPerYear;
           $this-> PriceMember = $PriceMember;
           $this->PriceNotMember = $PriceNotMember;
}
public static function getAll()
{
	$RateBadmintonList=[];
	require_once("connection_connect.php");
	$sql = "select * from RateBadminton";
	$result = $conn->query($sql);
	
	while ($my_row=$result->fetch_assoc())
		{

			$RateBadmintonID=$my_row['RateBadmintonID'];
			$TypeRatePerson=$my_row['TypeRatePerson'];
			$TerminalGym=$my_row['TerminalGym'];
			$PriceMemberPerYear=$my_row['PriceMemberPerYear'];
			$PriceMember=$my_row['PriceMember'];
			$PriceNotMember=$my_row['PriceNotMember'];
			$RateBadmintonList[]=new RateBadminton($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember);
		}
		require("connection_close.php");
		return $RateBadmintonList;
}
}?>