<?php class BadmintonTable{
	public $BadmintonID,$BadmintonCourt,$TerminalGym,$StatusCourt;
	public function BadmintonTable($BadmintonID,$BadmintonCourt,$TerminalGym,$StatusCourt)
	{
		$this->BadmintonID = $BadmintonID;
		$this->BadmintonCourt = $BadmintonCourt;
		$this->TerminalGym = $TerminalGym;
		$this->StatusCourt = $StatusCourt;
	}
	public static function getAll()
	{
		$BadmintonTableList=[];
		require("connection_connect.php");
		$sql="select * from badmintontable";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{

			$BadmintonID=$my_row['BadmintonID'];
			$BadmintonCourt=$my_row['BadmintonCourt'];
			$TerminalGym=$my_row['TerminalGym'];
			$StatusCourt=$my_row['StatusCourt'];
			$BadmintonTableList[]=new BadmintonTable($BadmintonID,$BadmintonCourt,$TerminalGym,$StatusCourt);
		}
		require("connection_close.php");
		return $BadmintonTableList;
		
		
	}
}?>