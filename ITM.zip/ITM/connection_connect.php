<?php
$servername = "localhost";
$username = "root";
$password = "370600";
$dbname = "Reserve_Badminton";
$conn =  new mysqli($servername, $username, $password);
if($conn->connect_error){
	die ("Connection failed:".$conn->connect_error);
}
if(!$conn->select_db($dbname)){
	die ("Connection failed:".$conn->connect_error);
}
?>
