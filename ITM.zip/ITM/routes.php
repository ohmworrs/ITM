<?php
$controllers=array('pages'=>['home','error'],'BadmintonTable'=>['index'],'Gym'=>['index'],'RateBadminton'=>['index']);

function call($controller,$action){
	require_once("controllers/".$controller."_Controller.php");
	switch($controller)
	{
		case "pages"		: 	$controller = new PagesController();
					  			break;
		case "BadmintonTable"	: require_once("models/BadmintonTableModel.php");
								$controller = new BadmintonTableController();
								break;
		case "UserReserve"	:	require_once("models/UserReserveModel.php");
								$controller = new UserReserveController();
								break;
		case "Gym"			:	require_once("models/GymModel.php")	;		
								$controller = new GymController();
								break;
		case "RateBadminton" :	require_once("models/RateBadmintonModel.php");
								$controller = new RateBadmintonController();
								break;
								
	}
	$controller->{$action}();
}

if(array_key_exists($controller,$controllers))
{
	if(in_array($action,$controllers[$controller]))
	{
		call($controller,$action);
	}
	else
		call('pages','error');
}
else{
	call('pages','error');	
}
?>