<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	
</body>
</html>

<div class="container">
            <form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="Recipient's username" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="View1" class="form-control" placeholder="ค้นหา" aria-label="Recipient's username" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2">Search</button>
						</div>
					</div>
				</form>
			<div><br></div>
			<table class="table table-striped table-dark"> 
  			<thead class="thead-dark">
   				 <tr align ='center' >
                    <th scope="col">TypeID</th>
                    <th scope="col">TypeName</th>
    			</tr>
  			</thead></tr>
<?php 
foreach($EquipmentTypeList as $EquipmentType)
{
    echo "<tr align ='center'>   
                 <td data - label = 'AdvisorID'>$EquipmentType->TypeID</td>
                 <td data - label = 'AdvisorName'>$EquipmentType->TypeName </td>
            </tr>";     
}
echo "</table>"; 
?>

		</div>   
	</body>
</html>	





	

