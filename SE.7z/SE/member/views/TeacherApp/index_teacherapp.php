<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous"> 
	</head>

	<body>
		<div class="container">
            <form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="Recipient's username" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="View1" class="form-control" placeholder="ค้นหา" aria-label="Recipient's username" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2">Search</button>
						</div>
					</div>
				</form>
			<div><br></div>
			<table class="table table-striped table-dark"> 
  			<thead class="thead-dark">
   				 <tr align ='center' >
                    <th scope="col">TeacherAppID</th>
                    <th scope="col">ApproveEqID</th>
                    <th scope="col">TeacherID</th>
                    <th scope="col">UserCode</th>
                    <th scope="col">EquipmentID</th>
                    <th scope="col">EquipmentName</th>
                    <th scope="col">DateBorrow</th>
                    <th scope="col">DateReturn</th>
					<th scope="col">StatusReserve</th>
    			</tr>
  			</thead></tr>
		 <tbody style="">
<?php 
foreach($TeacherAppList as $TeacherApp)
{
    echo "<tr align ='center'>   
                 <td data - label = 'TeacherAppID'>$$TeacherApp->TeacherAppID</td>
                 <td data - label = 'ApproveEqID'>$TeacherApp->ApproveEqID</td>
                 <td data - label = 'TeacherID'>$TeacherApp->TeacherID</td>
                 <td data - label = 'UserCode'>$TeacherApp->UserCode</td>
                 <td data - label = 'EquipmentID'>$TeacherApp->EquipmentID e</td>
                 <td data - label = 'EquipmentName'>$TeacherApp->EquipmentName</td>
                 <td data - label = 'DateBorrow'>$TeacherApp->DateBorrow </td>
				 <td data - label = 'DateReturn'>$TeacherApp->DateReturn</td>
				 <td data - label = 'StatusReserve'>$TeacherApp->StatusReserve</td>
            </tr>";     
}
echo "</table>"; 
?>
			 </tbody>
		</div>   
	</body>
</html>	







	

