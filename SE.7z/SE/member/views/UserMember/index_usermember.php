<table border = 1>
<tr> <td>UserCode</td><td>NameTitle</td><td>UserFNameEn</td><td>UserLNameEn</td><td>UserFNameTh</td><td>UserLNameTh</td><td>UserEmail</td><td>UserGender</td><td>DepartmentCode</td></tr>
<?php 

foreach($UserMemberList as $UserMember)
{
	echo"<tr>
    <td>$UserMember->UserCode</td> 
    <td>$UserMember->NameTitle</td>
    <td>$UserMember->UserFNameEn</td>
    <td>$UserMember->UserLNameEn</td>
    <td>$UserMember->UserFNameTh</td> 
    <td>$UserMember->UserLNameTh</td> 
    <td>$UserMember->UserEmail</td> 
    <td>$UserMember->UserGender</td> 
    <td>$UserMember->DepartmentCode</td> </tr>"; 
    
}
echo "</table>";
?>
<html>
<head></head>
<body>
    <!--เพิ่มการจอง [<a href=?controller=UserMember&action=newUserMember>Click</a>]-->
</body>
</html>	


