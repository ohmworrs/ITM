<?php 
class UserMember{
public $UserCode;
public $NameTitle;
public $UserFNameEn;
public $UserLNameEn;
public $UserFNameTh;
public $UserLNameTh;
public $UserEmail;
public $UserGender;
public $DepartmentCode;

public function UserMember($UserCode,$NameTitle,$UserFNameEn,$UserLNameEn,$UserFNameTh,$UserLNameTh,$UserEmail,$UserGender,$DepartmentCode)
{
	
	$this->UserCode = $UserCode;
    $this->NameTitle = $NameTitle;
	$this->UserFNameEn = $UserFNameEn;
    $this->UserLNameEn = $UserLNameEn;
    $this->UserFNameTh = $UserFNameTh;
    $this->UserLNameTh = $UserLNameTh;
    $this->UserEmail = $UserEmail;
    $this->UserGender = $UserGender;
    $this->DepartmentCode = $DepartmentCode;
}


public static function get($Code)
{
  require("connection_connect.php");
  $sql = "select * from UserMember where UserCode='$Code' ";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $UserCode=$my_row['UserCode'];
  $NameTitle=$my_row['NameTitle'];
  $UserFNameEn=$my_row['UserFNameEn'];
  $ResreveEmail=$my_row['UserLNameEn'];
  $UserFNameTh=$my_row['UserFNameTh'];
  $UserLNameTh=$my_row['UserLNameTh'];
  $UserEmail=$my_row['UserEmail'];
  $UserGender=$my_row['UserGender'];
  $DepartmentCode=$my_row['DepartmentCode'];
  
  require("connection_close.php");

  return new UserMember($UserCode,$NameTitle,$UserFNameEn,$UserLNameEn,$UserFNameTh,$UserLNameTh,$UserEmail,$UserGender,$DepartmentCode);
}

public static function getAll()
{
  $UserMemberList=[];
  require("connection_connect.php");
  $sql = "SELECT * FROM UserMember";
  $result=$conn->query($sql);
  while($my_row = $result->fetch_assoc())
{
  $UserCode=$my_row['UserCode'];
  $NameTitle=$my_row['NameTitle'];
  $UserFNameEn=$my_row['UserFNameEn'];
  $UserLNameEn=$my_row['UserLNameEn'];
  $UserFNameTh=$my_row['UserFNameTh'];
  $UserLNameTh=$my_row['UserLNameTh'];
  $UserEmail=$my_row['UserEmail'];
  $UserGender=$my_row['UserGender'];
  $DepartmentCode=$my_row['DepartmentCode'];
  
  $UserMemberList[]=new UserMember($UserCode,$NameTitle,$UserFNameEn,$UserLNameEn,$UserFNameTh,$UserLNameTh,$UserEmail,$UserGender,$DepartmentCode) ;
  
}

require("connection_close.php");
return $UserMemberList;
}

/*public static function search($key)
{	require("connection_connect.php");
    $sql = "select UserMember.UserCode, UserMember.NameTitle, UserMember.UserFNameEn, UserMember.UserLNameEn, UserMember.TimeCode, UserMember.BadmintonCode
    from UserMember,Badminton,Time 
    where (UserCode like'%$key%' or NameTitle like'%$key%' or UserFNameEn like'%$key%' or UserLNameEn like'%$key%' or TimeCode like'%$key%' or BadmintonCode like'%$key%')
    AND UserMember.TimeCode=Time.TimeCode AND UserMember.BadmintonCode=Badminton.BadmintonCode";
    $result=$conn->query($sql);
	while($my_row = $result->fetch_assoc())
	{
		$UserCode=$my_row['UserCode'];
        $NameTitle=$my_row['NameTitle'];
        $UserFNameEn=$my_row['UserFNameEn'];
        $ResreveEmail=$my_row['UserLNameEn'];
        $TimeCode=$my_row['TimeCode'];
        
		$UserMemberList[]= new UserMember($UserCode,$NameTitle,$UserFNameEn,$UserLNameEn,$TimeCode);
	}
		require("connection_close.php");
		return $UserMemberList;
}*/

/*public static function add($NameTitle,$UserFNameEn,$UserLNameEn,$UserFNameTh,$UserLNameTh,$UserEmail,$UserGender,$DepartmentCode)
{	require("connection_connect.php");

    $sql = "insert into UserMember(NameTitle,UserFNameEn,UserLNameEn,UserFNameTh,UserLNameTh,UserEmail,UserGender,DepartmentCode,BadmintonCode)
    values ('$NameTitle','$UserFNameEn','$UserLNameEn','$UserFNameTh','$UserLNameTh','$UserEmail','$UserGender','$DepartmentCode','$BadmintonCode')";
    $result=$conn->query($sql);
    $sql = "UPDATE Badminton SET StatusCourt='จองแล้ว' where BadmintonCode='$BadmintonCode'";
    $result=$conn->query($sql);
   
   
	require("connection_close.php");
	return "add success $result rows";}

public static function update($UserCode,$NameTitle,$UserFNameEn,$UserLNameEn,$TimeCode)
{	require("connection_connect.php");
    $sql = "update UserMember set NameTitle='$NameTitle',UserFNameEn='$UserFNameEn',UserLNameEn='$UserLNameEn',TimeCode='$TimeCode',BadmintonCode='$BadmintonCode'
    where UserMember.UserCode='$UserCode' ";
    $result=$conn->query($sql);
	require("connection_close.php");
	return "update success $result rows";}

public static function delete($Code)
{	require("connection_connect.php");
	$sql = "Delete from UserMember Where UserMember.UserCode='$Code'";
    $result=$conn->query($sql);
	require("connection_close.php");
    return "delete success $result rows";
}*/


}




