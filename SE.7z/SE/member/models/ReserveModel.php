<?php 
class Reserve{
public $ReserveID;
public $ReserveName;
public $ReserveTel;
public $ReserveEmail;
public $TypePerson;
public $BadmintonCourt;
public $TerminalGym;
public $TimeStart;
public $TimeFinish;
public $BadmintonID;

public function Reserve($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$BadmintonID)
{
	
	$this->ReserveID = $ReserveID;
    $this->ReserveName = $ReserveName;
	$this->ReserveTel = $ReserveTel;
    $this->ReserveEmail = $ReserveEmail;
    $this->TypePerson = $TypePerson;
    $this->BadmintonCourt = $BadmintonCourt;
    $this->TerminalGym = $TerminalGym;
    $this->TimeStart = $TimeStart;
    $this->TimeFinish = $TimeFinish;
    $this->BadmintonID = $BadmintonID;
    
    
}


public static function get($ID)
{
  require("connection_connect.php");
  $sql = "select Reserve.ReserveID, Reserve.ReserveName, Reserve.ReserveTel, Reserve.ReserveEmail,Reserve.TypePerson,Reserve.BadmintonCourt,Reserve.TerminalGym,Reserve.TimeStart,Reserve.TimeFinish, Reserve.BadmintonID
  from Reserve,Badminton
  where ReserveID='$ID' AND Reserve.BadmintonID=Badminton.BadmintonID";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $ReserveID=$my_row['ReserveID'];
  $ReserveName=$my_row['ReserveName'];
  $ReserveTel=$my_row['ReserveTel'];
  $ResreveEmail=$my_row['ReserveEmail'];
  $TypePerson=$my_row['TypePerson'];
  $BadmintonCourt=$my_row['BadmintonCourt'];
  $TerminalGym=$my_row['TerminalGym'];
  $TimeStart=$my_row['TimeStart'];
  $TimeFinish=$my_row['TimeFinish'];
  $BadmintonID=$my_row['BadmintonID'];
  require("connection_close.php");

  return new Reserve($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$BadmintonID);
}

public static function getAll()
{
  $ReserveList=[];
  require("connection_connect.php");
  $sql = "SELECT * FROM Reserve";
  $result=$conn->query($sql);
  while($my_row = $result->fetch_assoc())
{
  $ReserveID=$my_row['ReserveID'];
  $ReserveName=$my_row['ReserveName'];
  $ReserveTel=$my_row['ReserveTel'];
  $ReserveEmail=$my_row['ReserveEmail'];
  $TypePerson=$my_row['TypePerson'];
  $BadmintonCourt=$my_row['BadmintonCourt'];
  $TerminalGym=$my_row['TerminalGym'];
  $TimeStart=$my_row['TimeStart'];
  $TimeFinish=$my_row['TimeFinish'];
  $BadmintonID=$my_row['BadmintonID'];
  $ReserveList[]=new Reserve($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$BadmintonID) ;
  
}

require("connection_close.php");
return $ReserveList;
}

/*public static function search($key)
{	require("connection_connect.php");
    $sql = "select Reserve.ReserveID, Reserve.ReserveName, Reserve.ReserveTel, Reserve.ReserveEmail, Reserve.TimeID, Reserve.BadmintonID
    from Reserve,Badminton,Time 
    where (ReserveID like'%$key%' or ReserveName like'%$key%' or ReserveTel like'%$key%' or ReserveEmail like'%$key%' or TimeID like'%$key%' or BadmintonID like'%$key%')
    AND Reserve.TimeID=Time.TimeID AND Reserve.BadmintonID=Badminton.BadmintonID";
    $result=$conn->query($sql);
	while($my_row = $result->fetch_assoc())
	{
		$ReserveID=$my_row['ReserveID'];
        $ReserveName=$my_row['ReserveName'];
        $ReserveTel=$my_row['ReserveTel'];
        $ResreveEmail=$my_row['ReserveEmail'];
        $TimeID=$my_row['TimeID'];
        $BadmintonID=$my_row['BadmintonID'];
		$ReserveList[]= new Reserve($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID);
	}
		require("connection_close.php");
		return $ReserveList;
}*/

public static function add($ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$BadmintonID)
{	require("connection_connect.php");

    $sql = "insert into Reserve(ReserveName,ReserveTel,ReserveEmail,TypePerson,BadmintonCourt,TerminalGym,TimeStart,TimeFinish,BadmintonID)
    values ('$ReserveName','$ReserveTel','$ReserveEmail','$TypePerson','$BadmintonCourt','$TerminalGym','$TimeStart','$TimeFinish','$BadmintonID')";
    $result=$conn->query($sql);
    
	require("connection_close.php");
	return "add success $result rows";}

/*public static function update($ReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID)
{	require("connection_connect.php");
    $sql = "update Reserve set ReserveName='$ReserveName',ReserveTel='$ReserveTel',ReserveEmail='$ReserveEmail',TimeID='$TimeID',BadmintonID='$BadmintonID'
    where Reserve.ReserveID='$ReserveID' ";
    $result=$conn->query($sql);
	require("connection_close.php");
	return "update success $result rows";}

public static function delete($ID)
{	require("connection_connect.php");
	$sql = "Delete from Reserve Where Reserve.ReserveID='$ID'";
    $result=$conn->query($sql);
	require("connection_close.php");
    return "delete success $result rows";
}*/
}




