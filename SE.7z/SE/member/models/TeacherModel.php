<?php 
class Teacher{
	public $TeacherID,$TeacherName,$Position;
	public function Teacher($TeacherID,$TeacherName,$Position)
	{
		$this->TeacherID = $TeacherID;
        $this->TeacherName = $TeacherName;
        $this->Position = $Position;
		
	}

	public static function get($id)
{
  require("connection_connect.php");
  $sql = "select *from Teacher where TeacherID='$id'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $TeacherID=$my_row['TeacherID'];
  $TeacherName=$my_row['TeacherName'];
  $Position=$my_row['Position'];
 
  require("connection_close.php");

  return new Teacher($TeacherID,$TeacherName,$Position);
}
	public static function getAll()
	{
		$TeacherList=[];
		require("connection_connect.php");
		$sql="select * from Teacher";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$TeacherID=$my_row['TeacherID'];
            $TeacherName=$my_row['TeacherName'];
            $Position=$my_row['Position'];
			
			$TeacherList[]=new Teacher($TeacherID,$TeacherName,$Position);
		}
		require("connection_close.php");
		return $TeacherList;
		
		
	}
	public static function search($key)
	{
		$TeacherList=[];
		require_once("connection_connect.php");
		$sql="select *from Teachers
		where (TeacherID$TeacherID like'%$key%' or TeacherName like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$TeacherID=$my_row['TeacherID'];
            $TeacherName=$my_row['TeacherName'];
            $Position=$my_row['Position'];
			
			$TeacherList[]=new Teacher($TeacherID,$TeacherName,$Position);
		}
		require("connection_close.php");
		return $TeacherList;

	}
}?>