<?php 
class TeacherApp{
	public $TeacherAppID,$ApproveEqID,$TeacherID,$UserCode,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn,$StatusReserve;
	public function TeacherApp($TeacherAppID,$ApproveEqID,$TeacherID,$UserCode,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn,$StatusReserve)
	{
		$this->TeacherAppID = $TeacherAppID;
		$this->ApproveEqID = $ApproveEqID;
		$this->TeacherID = $TeacherID;
		$this->UserCode = $UserCode;
		$this->EquipmentID = $EquipmentID;
		$this->EquipmentName = $EquipmentName;
		$this->DateBorrow = $DateBorrow;
		$this->DateReturn = $DateReturn;
		$this->StatusReserve = $StatusReserve;
	}

	public static function get($id)
{
  require("connection_connect.php");
  $sql = "select *from TeacherApp where TeacherAppID='$id'";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $TeacherAppID=$my_row['TeacherAppID$TeacherAppID'];
  $ApproveEqID=$my_row['ApproveEqID'];
  $TeacherID=$my_row['TeacherID'];
  $UserCode=$my_row['UserCode'];
  $EquipmentID=$my_row['EquipmentID'];
  $EquipmentName=$my_row['EquipmentName'];
  $DateBorrow=$my_row['DateBorrow'];
  $DateReturn=$my_row['DateReturn'];
  $StatusReserve=$my_row['StatusReserve'];
 
  require("connection_close.php");

  return new TeacherApp($TeacherAppID,$ApproveEqID,$TeacherID,$UserCode,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn,$StatusReserve);
}
	public static function getAll()
	{
		$TeacherAppList=[];
		require("connection_connect.php");
		$sql="select * from TeacherApp";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$TeacherAppID=$my_row['TeacherAppID'];
			$ApproveEqID=$my_row['ApproveEqID'];
			$TeacherID=$my_row['TeacherID'];
			$UserCode=$my_row['UserCode'];
  			$EquipmentID=$my_row['EquipmentID'];
 			$EquipmentName=$my_row['EquipmentName'];
  			$DateBorrow=$my_row['DateBorrow'];
  			$DateReturn=$my_row['DateReturn'];
			  $StatusReserve=$my_row['StatusReserve'];
			
			$TeacherAppList[]=new TeacherApp($TeacherAppID,$ApproveEqID,$TeacherID,$UserCode,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn,$StatusReserve);
		}
		require("connection_close.php");
		return $TeacherAppList;
		
		
	}
	public static function search($key)
	{
		$TeacherAppList=[];
		require_once("connection_connect.php");
		$sql="select *from TeacherApps
		where (TeacherAppID like'%$key%' or ApproveEqID like'%$key%' or TeacherID like'%$key%' or UserCode like'%$key%' or EquipmentID like'%$key%' or EquipmentName like'%$key%' or DateBorrow like'%$key%' or DateReturn like'%$key%' or StatusReserve like'%$key%')";
		$result=$conn->query($sql);
		while ($my_row=$result->fetch_assoc())	
		{
			$TeacherAppID=$my_row['TeacherAppID$TeacherAppID'];
			$ApproveEqID=$my_row['ApproveEqID'];
			$TeacherID=$my_row['TeacherID'];
			$UserCode=$my_row['UserCode'];
  			$EquipmentID=$my_row['EquipmentID'];
  			$EquipmentName=$my_row['EquipmentName'];
  			$DateBorrow=$my_row['DateBorrow'];
  			$DateReturn=$my_row['DateReturn'];
			$StatusReserve=$my_row['StatusReserve'];
			
			$TeacherAppList[]=new TeacherApp($TeacherAppID,$ApproveEqID,$TeacherID,$UserCode,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn,$StatusReserve);
		}
		require("connection_close.php");
		return $TeacherAppList;

	}
	public static function add($ApproveEqID,$TeacherID,$UserCode,$EquipmentID,$EquipmentName,$DateBorrow,$DateReturn,$StatusReserve)
	{
		require("connection_connect.php");

    	$sql = "insert into TeacherApp(ApproveEqID,TeacherID,UserCode,EquipmentID,EquipmentName,DateBorrow,DateReturn,StatusReserve)
		values ('$ApproveEqID','$TeacherID','$UserCode','$EquipmentID','$EquipmentName','$DateBorrow','$DateReturn','$StatusReserve')";
		$result=$conn->query($sql);
		

		$sql="DELETE from ApproveEquipment where ApproveEquipmentID='$ApproveEqID'";	
		$result=$conn->query($sql);


		$sql="UPDATE Equipment SET Equipment.EquipmentStatus='ไม่พร้อมใช้งาน' where EquipmentID='$EquipmentID'";	
		$result=$conn->query($sql);

		require("connection_close.php");
		return "add success $result rows";
	}
}?>