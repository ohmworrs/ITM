<?php 
class UserMemberController
{
	

	public function index()
	{
		
		$UserMemberList=UserMember::getAll();
		require_once('views/UserMember/index_usermember.php');
	}
	public function updateForm()
	{
		$Code = $_GET['UserMemberCode'];
		$UserMember = UserMember::get($Code);
		
	}
}?>