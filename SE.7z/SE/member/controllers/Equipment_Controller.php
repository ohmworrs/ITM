<?php 
class EquipmentController
{
	public function index()
	{
		$EquipmentList=Equipment::getAll();
		require_once('views/Equipment/index_equipment.php');
	}
}?>