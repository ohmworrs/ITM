<?php 
class AdvisorController
{
	public function index()
	{
		$AdvisorList=Advisor::getAll();
		require_once('views/Advisor/index_advisor.php');
	}
}?>