<?php 
class DepartmentController
{
	public function index()
	{
		$DepartmentList=Department::getAll();
		require_once('views/Department/index_department.php');
	}
}?>