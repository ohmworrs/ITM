<?php 
class EquipmentINCartController
{
	public function index()
	{
		$EquipmentINCartList=EquipmentINCart::getAll();
		require_once('views/EquipmentINCart/index_equipmentincart.php');
    }
    
    public function newEquipmentINCart ()
    {
		
		$Code=$_GET['EquipmentID'];
		$Equipment = Equipment::get($Code ); 
		$AdvisorList = Advisor::getAll();
		$EquipmenINCartList = EquipmentINCart::getAll();
        $EquipmentList=Equipment::getAll();
        $EquipmentTypeList=EquipmentType::getAll();
        $UserMemberList=UserMember::getAll();
        require_once('views/EquipmentINCart/newEquipmentINCart.php');

    }

    public function addEquipmentINCart()
	{
		
        $UserCode=$_GET['UserCode'];
		$EquipmentID=$_GET['EquipmentID'];
		$EquipmentName=$_GET['EquipmentName'];
		$EquipmentDetail=$_GET['EquipmentDetail'];
		$EquipmentImage=$_GET['EquipmentImage'];
		$TypeID=$_GET['TypeID'];
		$DateBorrow=$_GET['DateBorrow'];
		$DateReturn=$_GET['DateReturn'];
		$Reason=$_GET['Reason'];
		$AdvisorID=$_GET['AdvisorID'];


	
		EquipmentINCart::add($UserCode,$EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentImage,$TypeID,$DateBorrow,$DateReturn,$Reason,$AdvisorID);
		EquipmentINCartController::index();
	
	}
	public function deleteConfirm()
	{
		$EquipmentINCartID=$_GET['EquipmentINCartID'];
		$EquipmentINCart=EquipmentINCart::get($EquipmentINCartID);
		require_once('views/EquipmentINCart/deleteConfirm.php');
	}
	public function delete()
	{
			$EquipmentINCartID=$_GET['EquipmentINCartID'];
			EquipmentINCart::delete($EquipmentINCartID);
			EquipmentINCartController::index();
	}


}?>