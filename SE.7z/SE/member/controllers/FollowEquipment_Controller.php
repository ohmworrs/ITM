<?php 
class FollowEquipmentController
{
	public function index()
	{
		$FollowEquipmentList=FollowEquipment::getAll();
		require_once('views/FollowEquipment/index_followequipment.php');
    }
    
  /*  public function newFollowEquipment ()
    {
		
		$Code=$_GET['EquipmentID'];
		$Equipment = Equipment::get($Code ); 
		$AdvisorList = Advisor::getAll();
		$EquipmenINCartList = FollowEquipment::getAll();
        $EquipmentList=Equipment::getAll();
        $EquipmentTypeList=EquipmentType::getAll();
        $UserMemberList=UserMember::getAll();
        require_once('views/FollowEquipment/newFollowEquipment.php');

    }

    public function addFollowEquipment()
	{
		
        $UserCode=$_GET['UserCode'];
		$EquipmentID=$_GET['EquipmentID'];
		$EquipmentName=$_GET['EquipmentName'];
		$EquipmentDetail=$_GET['EquipmentDetail'];
		$EquipmentImage=$_GET['EquipmentImage'];
		$TypeID=$_GET['TypeID'];
		$DateBorrow=$_GET['DateBorrow'];
		$DateReturn=$_GET['DateReturn'];
		$Reason=$_GET['Reason'];
		$AdvisorID=$_GET['AdvisorID'];


	
		FollowEquipment::add($UserCode,$EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentImage,$TypeID,$DateBorrow,$DateReturn,$Reason,$AdvisorID);
		FollowEquipmentController::index();
	
	}
	public function deleteConfirm()
	{
		$FollowEquipmentID=$_GET['FollowEquipmentID'];
		$FollowEquipment=FollowEquipment::get($FollowEquipmentID);
		require_once('views/FollowEquipment/deleteConfirm.php');
	}
	public function delete()
	{
			$FollowEquipmentID=$_GET['FollowEquipmentID'];
			FollowEquipment::delete($FollowEquipmentID);
			FollowEquipmentController::index();
	}*/


}?>