<form method="get" action="">
<label> TypeID<input type="text" name="TypeID"
value="<?php echo $EquipmentType->TypeID; ?>" /> </label><br>
<label>TypeName <input type="text" name="TypeName" 
value="<?php echo $EquipmentType->TypeName; ?>"/> </label><br>


<input type="hidden" name="controller" value="EquipmentType"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="update"> Save</button>

</form>
