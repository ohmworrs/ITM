<html>
<head></head>
<body>
<form method="get" action="">
<label>ชื่อบุคลากร<input type="text" name="PersonnelName" /> </label><br>

<label>เลขครุภัณฑร์ <input type="text" name="EquipmentID" readonly="true" 
    value="<?php echo $Equipment->EquipmentID;?>" /> </label><br>

<label>ชื่ออุปกรณ์<input type="text" name="EquipmentName" readonly="true" 
    value="<?php echo $Equipment->EquipmentName;?>"/> </label><br>





<label>วันที่มายืมอุปกรณ์ <input type="Date" name="DateBorrow" /> </label><br>

<label>วันที่คืนอุปกรณ์ <input type="Date" name="DateReturn" /> </label><br>





<input type="hidden" name="controller" value="PersonnelEq"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addPersonnelEq" > Save</button>




</body>
</html>




