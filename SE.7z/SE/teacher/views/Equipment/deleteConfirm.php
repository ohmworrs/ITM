<?php echo "<br>Are you sure to delete  <br>
            <br>$Equipment->EquipmentID  <br>";  ?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="Equipment"/>
    <input type="hidden" name="EquipmentID" value="<?php echo $Equipment->EquipmentID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>
