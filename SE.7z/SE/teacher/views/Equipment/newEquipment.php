
<html>
<head></head>
<body>
<form method="get" action="">

<label>เลขครุภัณฑร์ <input type="text" name="EquipmentID" /> </label><br>

<label>ชื่ออุปกรณ์<input type="text" name="EquipmentName" /> </label><br>

<label>รายละเอียด <input type="text" name="EquipmentDetail"/> </label><br>

<label>สถานะอุปกรณ์<input type="text" name="EquipmentStatus" /> </label><br>

<label>ภาพอุปกรณ์<input type="text" name="EquipmentImage" /> </label><br>

<label>หมวดอุปกรณ์<select name="TypeID" >
        <?php foreach($EquipmentTypeList as $EquipmentType){
            echo "<option value=$EquipmentType->TypeID>$EquipmentType->TypeName</option>";
        }?>
 </select></label><br>




<input type="hidden" name="controller" value="Equipment"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addEquipment" > Save</button>




</body>
</html>




