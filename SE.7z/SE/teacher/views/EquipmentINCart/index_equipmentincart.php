<table border=1>
	<tr> <td>EquipmentINCartID</td><td>UserCode</td><td>EquipmentID</td><td>EquipmentName</td><td>EquipmentDetail</td>
		<td>EquipmentImage</td><td>TypeID</td><td>DateBorrow</td><td>DateReturn</td><td>Reason</td><td>Advisor</td><td>Cancel</td>
		<td>ร้องขอการอนุมัติ</td></tr>

		

<?php foreach($EquipmentINCartList as $EquipmentINCart)
{
	echo "
            <td>$EquipmentINCart->EquipmentINCartID </td>
            <td>$EquipmentINCart->UserCode</td>
            <td>$EquipmentINCart->EquipmentID </td>
			<td>$EquipmentINCart->EquipmentName </td>
			<td>$EquipmentINCart->EquipmentDetail </td>
			<td>$EquipmentINCart->EquipmentImage </td>
			<td>$EquipmentINCart->TypeID  </td>
			<td>$EquipmentINCart->DateBorrow  </td>
			<td>$EquipmentINCart->DateReturn  </td>
			<td>$EquipmentINCart->Reason  </td>
			<td>$EquipmentINCart->AdvisorID  </td>
			<td><a href=?controller=EquipmentINCart&action=deleteConfirm&EquipmentINCartID=$EquipmentINCart->EquipmentINCartID>delete</a></td>
			<td><a href=?controller=ApproveEquipment&action=newApproveEquipment&EquipmentINCartID=$EquipmentINCart->EquipmentINCartID>ขออนุมัติ</a></td></tr>";	
				
}
	echo "</table>";
	
	
	
?>

<html>
<head>
	<title></title>
</head>
<body>
	<br>
	
</body>
</html>