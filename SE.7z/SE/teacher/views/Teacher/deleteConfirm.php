<?php echo "<br>Are you sure to delete this<br>
            <br>$Teacher->TeacherID $Teacher->TeacherName <br>";?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="Teacher"/>
    <input type="hidden" name="TeacherID" value="<?php echo $Teacher->TeacherID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>
