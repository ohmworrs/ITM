<?php echo "<br>Are you sure to delete this<br>
            <br>$Advisor->AdvisorID $Advisor->AdvisorName <br>";?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="Advisor"/>
    <input type="hidden" name="AdvisorID" value="<?php echo $Advisor->AdvisorID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>
