<table border=1>
	<tr> <td>ApproveEquipmentID</td><td>EquipmentINCartID</td><td>UserCode</td><td>EquipmentID</td><td>EquipmentName</td><td>EquipmentDetail</td>
		<td>EquipmentImage</td><td>TypeID</td><td>DateBorrow</td><td>DateReturn</td><td>Reason</td><td>Advisor</td><td>อนุมัติ</td>
		<td>ไม่อนุมัติ</td></tr>

		

<?php foreach($ApproveEquipmentList as $ApproveEquipment)
{
    echo "
            <td>$ApproveEquipment->ApproveEquipmentID </td>
            <td>$ApproveEquipment->EquipmentINCartID </td>
            <td>$ApproveEquipment->UserCode</td>
            <td>$ApproveEquipment->EquipmentID </td>
			<td>$ApproveEquipment->EquipmentName </td>
			<td>$ApproveEquipment->EquipmentDetail </td>
			<td>$ApproveEquipment->EquipmentImage </td>
			<td>$ApproveEquipment->TypeID  </td>
			<td>$ApproveEquipment->DateBorrow  </td>
			<td>$ApproveEquipment->DateReturn  </td>
			<td>$ApproveEquipment->Reason  </td>
			<td>$ApproveEquipment->AdvisorID  </td>
			<td><a href=?controller=TeacherApp&action=newTeacherApp&ApproveEquipmentID=$ApproveEquipment->ApproveEquipmentID>อนุมัติ</a></td>
			<td><a href=?controller=ApproveEquipment&action=deleteConfirm&ApproveEquipmentID=$ApproveEquipment->ApproveEquipmentID>ไม่อนุมัติ</a></td></tr>";	
				
}
	echo "</table>";
	
	
	
?>

<html>
<head>
	<title></title>
</head>
<body>
	<br>
	
</body>
</html>