<table border=1>
	<tr> <td>TeacherID</td><td>TeacherName</td><td>Position</td><td>อัพเดท</td><td>ลบ</td></tr>

		

<?php foreach($TeacherList as $Teacher)
{
	echo "  <td>$Teacher->TeacherID </td>
            <td>$Teacher->TeacherName </td>
            <td>$Teacher->Position </td>
            <td><a href=?controller=Teacher&action=updateForm&TeacherID=$Teacher->TeacherID>updete</a></td>
            <td><a href=?controller=Teacher&action=deleteConfirm&TeacherID=$Teacher->TeacherID>dalete</a></td></tr>";			
}
    echo "</table>";
?>

<html>
<head>
	<title></title>
</head>
<body>
	<br>
	new Teacher <a href=?controller=Teacher&action=newTeacher>Click</a><br>
</body>
</html>

