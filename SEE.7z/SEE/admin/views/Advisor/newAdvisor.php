
<form method="get" action="">


<label>AdvisorName <input type="text" name="AdvisorName" /> </label><br>

<input type="hidden" name="controller" value="Advisor"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addAdvisor"> Save</button>

</form>



