<?php echo "<br>Are you sure to delete this<br>
            <br>$EquipmentType->TypeID $EquipmentType->TypeName <br>";?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="EquipmentType"/>
    <input type="hidden" name="TypeID" value="<?php echo $EquipmentType->TypeID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>
