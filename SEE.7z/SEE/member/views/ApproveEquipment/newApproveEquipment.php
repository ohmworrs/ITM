<html>
<head></head>
<body>
<form method="get" action="">
<label>หมายเลขตะกร้า <input type="int" name="EquipmentINCartID" readonly="true" 
    value="<?php echo $EquipmentINCart->EquipmentINCartID;?>" /> </label><br>

<label>รหัสนิสิต <input type="text" name="UserCode" readonly="true" 
    value="<?php echo $EquipmentINCart->UserCode;?>" /> </label><br>

<label>เลขครุภัณฑร์ <input type="text" name="EquipmentID" readonly="true" 
    value="<?php echo $EquipmentINCart->EquipmentID;?>" /> </label><br>

<label>ชื่ออุปกรณ์<input type="text" name="EquipmentName" readonly="true" 
    value="<?php echo $EquipmentINCart->EquipmentName;?>"/> </label><br>
<label>รายละเอียด <input type="text" name="EquipmentDetail"readonly="true" 
    value="<?php echo $EquipmentINCart->EquipmentDetail;?>"/> </label><br>

<label>ภาพอุปกรณ์<input type="text" name="EquipmentImage" readonly="true" 
    value="<?php echo $EquipmentINCart->EquipmentImage;?>"/> </label><br>
<label>หมวดอุปกรณ์<input type="text" name="TypeID" readonly="true" 
    value="<?php echo $EquipmentINCart->TypeID;?>"/> </label><br>
<label>วันที่มายืมอุปกรณ์ <input type="Date" name="DateBorrow" readonly="true" 
    value="<?php echo $EquipmentINCart->DateBorrow;?>"/> </label><br>

<label>วันที่คืนอุปกรณ์ <input type="Date" name="DateReturn" readonly="true" 
    value="<?php echo $EquipmentINCart->DateReturn;?>"/> </label><br>

<label>เหตุผลที่ยืม<input type="text" name="Reason" readonly="true" 
    value="<?php echo $EquipmentINCart->Reason;?>"/> </label><br>

<label>อาจารย์ที่ปรึกษาโครงงาน<input type="int" name="AdvisorID"readonly="true" 
    value="<?php echo $EquipmentINCart->AdvisorID;?>"></label><br>


<input type="hidden" name="controller" value="ApproveEquipment"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addApproveEquipment" > Save</button>




</body>
</html>




